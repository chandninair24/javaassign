package com.cg.mobile.test;

import java.time.LocalDate;

import org.junit.Test;

import junit.framework.Assert;

import com.cg.mobile.dao.*;
import com.cg.mobile.dto.Mobiles;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileException;

public class MobileTest {

	@Test
	public void testValidInsert(){
		PurchaseDetails s1= new PurchaseDetails();
		s1.setMobileId(1001);
		s1.setCname("chandni");
		s1.setMailId("chandni@capgemini.com");
		s1.setPhoneNo("8056342399");
		s1.setPurchaseId(102);
		
		IMobileDao dao= new MobileDaoImpl();
		try {
			PurchaseDetails s=dao.addDetails(s1);
			Assert.assertNotSame(0,s.getMobileId());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	@Test(expected=MobileException.class)
	public void testInsertForInvalid() throws MobileException{
		PurchaseDetails s1= new PurchaseDetails();
		s1.setMobileId(1001);
		s1.setCname("chandni");
		s1.setMailId("chandni@capgemini.com");
		s1.setPhoneNo("8056342399");
		s1.setPurchaseId(102);
		IMobileDao dao= new MobileDaoImpl();
		PurchaseDetails s=dao.addDetails(s1);
	}
	
	
}//class closed
	
	
	
	
	
	