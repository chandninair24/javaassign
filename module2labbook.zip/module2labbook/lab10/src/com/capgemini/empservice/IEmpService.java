package com.capgemini.empservice;

import com.capgemini.exception.EmployeeException;
import com.capgemini.lab10.Employee;

public interface IEmpService {
	public Employee addEmployee(Employee employee)throws EmployeeException;
}
