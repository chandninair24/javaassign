package com.capgemini.empservice;

import com.capgemini.empdao.Empdao;
import com.capgemini.empdao.IEmpdao;
import com.capgemini.exception.EmployeeException;
import com.capgemini.lab10.Employee;





public class EmpService implements  IEmpService {
	IEmpdao dao;
	public EmpService(){
		dao=new Empdao();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	@Override
	public Employee addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}



}
