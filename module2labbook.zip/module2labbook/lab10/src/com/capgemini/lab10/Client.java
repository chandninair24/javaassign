package com.capgemini.lab10;

import java.util.Scanner;

import com.capgemini.empservice.EmpService;
import com.capgemini.empservice.IEmpService;
import com.capgemini.exception.EmployeeException;

public class Client {

	public static void main(String[] args) {
		
		Employee e=new Employee();
		IEmpService service=new EmpService();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id");
		int empid=sc.nextInt();
		System.out.println("Enter the name:");
		String name=sc.next();
		System.out.println("Enter the salary:");
		int salary=sc.nextInt();
		System.out.println("Enter the gender");
		String gender=sc.next();
	    System.out.println("enter insurance scheme");
		String insurancescheme=sc.next();
		
		e.setEmpid(empid);
		e.setName(name);
		e.setGender(gender);
		e.setSalary(salary);
		e.setInsurancescheme(insurancescheme);
		try{
			Employee e1=service.addEmployee(e);
			System.out.println("Employee added to the db.....");
			
		}catch(EmployeeException e1){
			System.out.println(e1.getMessage());
		}
	}

}
