package com.capgemini.empdao;

import com.capgemini.exception.EmployeeException;
import com.capgemini.lab10.Employee;

public interface IEmpdao {
	public Employee addEmployee(Employee employee)throws EmployeeException;
}
