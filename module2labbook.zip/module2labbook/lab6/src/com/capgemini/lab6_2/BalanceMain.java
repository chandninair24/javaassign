package com.capgemini.lab6_2;

	public class BalanceMain {
		public static void main(String[] args) {
			Person p1=new Person();
			Person p2 = new Person();
			p1.setName("Chandni");
			p1.setAge(22);
			p1.getName();
			p1.getAge();
			System.out.println(p1.getName());
			Account a1 = new Account();
			a1.setBalance(60000);
			Account a2 = new Account();
			a2.setBalance(45000);
			a1.deposit(7000);
			a2.withdraw(6000);
			System.out.println(a1);
			System.out.println(a2);
		}

	}


