package com.capgemini.lab4;

import java.util.Scanner;

public class SavingAccounts extends Account {
private final double minbalance ;
public SavingAccounts(long accnum, double balance, String name, float age){
	super(accnum, balance);
	minbalance= 500;
}
@Override
public boolean withDraw(double amt){
	if(getBalance()>= (amt+minbalance))
	setBalance(getBalance()-amt);
	else
		System.out.println("Cannot withdraw from your account "+getAccnum() );
	return true;
}
public static void main(String[] args) {
	SavingAccounts s1= new SavingAccounts(1234, 11000, "Anirudh", 22);
	System.out.println("Enter the amount to be withdrawn: ");
	Scanner sc= new Scanner(System.in);
	double amt= sc.nextInt();
	s1.withDraw(amt);
	System.out.println("Your current balance is: "+s1.getBalance());
	
}
}