package com.capgemini.lab2;

import java.util.Scanner;


enum Gender{
	M("Male"),F("Female");
	
	private String name;
	Gender(String gen){
		name = gen;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

public class Person {
	
	String first_name;
	String last_name;
	Gender gender;
	int age;
	public double weight;

    // Parameterized Constructor
	public Person(String first_name, String last_name, Gender gender, int age,double weight) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.gender = gender;
		this.age = age;
		this.weight=weight;
	}

    //Default Constructor
	public Person(){
		first_name = "First Name";
		last_name = "Last Name";
		age = 25;
		gender = Gender.M;
		weight=85;
		
	}
	
	
	
	@Override
	public String toString()
	{
		return first_name+" "+last_name+" "+gender+" "+age+" "+weight;
	}
	
	
	//Getter and Setters
	
	public String getfirst_name() {
		return first_name;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setfirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getlast_name() {
		return last_name;
	}

	public void setlast_name(String last_name) {
		this.last_name = last_name;
	}

	

	public double getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	//Phone number method
	public int phonenum() {
		System.out.println("Enter the age: ");
		Scanner scan = new Scanner(System.in);
		age = scan.nextInt();
		return age;
	}
	
	public void scan() {
		// TODO Auto-generated method stub
		System.out.println("Enter First Name:");
		Scanner first = new Scanner(System.in);
		this.first_name = first.next();
	
		System.out.println("Enter Last Name:");
		Scanner second = new Scanner(System.in);
		this.last_name = second.next(); 
		
		System.out.println("Enter Gender(M/F):");
		Scanner pnum = new Scanner(System.in);
		char Gen = pnum.next().charAt(0);
		if(Gen == 'M')
		{
			Gender gen = Gender.M;
			this.gender = gen;
		}
		else if(Gen == 'F'){
			Gender gen = Gender.F;
			this.gender = gen;
		}
		System.out.println("Enter the weight");
		Scanner sc=new Scanner(System.in);
		weight=sc.nextDouble();
		
		
	}
	
	
    //Display method
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Person Details:");
		System.out.println("-----------------");
		System.out.println("First name: "+ first_name  );
		System.out.println("Last name: "+ last_name);
		System.out.println("Gender: "+getGender().getName());
		System.out.println("Age: " +age);
		System.out.println("weight: "+weight );
	}

	
	
}
