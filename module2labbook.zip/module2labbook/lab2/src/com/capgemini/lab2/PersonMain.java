package com.capgemini.lab2;

import java.util.Scanner;

public class PersonMain{

public static void main(String[] args) {
		
	 
		Person person = new Person();
		person.scan();
		person.getAge();
		person.print();
		
	}
	
	
}
