package com.capgemini.lab2;

public class PersonalDetail {
	
	public static void main(String[] args) {
		
		System.out.println("Personal Details:");
		System.out.println("---------------------");
		System.out.println("First name: Divya");
		System.out.println("Last name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");
	}
}
