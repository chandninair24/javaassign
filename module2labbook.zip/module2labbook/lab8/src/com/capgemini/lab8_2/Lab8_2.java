package com.capgemini.lab8_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab8_2 {

	public static void main(String[] args) {

		File file = new File("nums.txt");
		
		try {
			Scanner sc = new Scanner(file);
			while(sc.hasNext()){
				String line = sc.next();
				String[] str = line.split(",");
				int arr[] = new int[str.length];
				for(int i=0;i<str.length;i++)
				{
					arr[i]=Integer.parseInt(str[i]);
					if(arr[i]==0)
						continue;
					else if(arr[i]%2==0)
						System.out.print(arr[i]+" ");
				}
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}

}
