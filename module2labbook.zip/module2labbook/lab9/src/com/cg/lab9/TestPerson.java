package com.cg.lab9;
import org.junit.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class TestPerson {

	@Test
	public void testGetFullName(){
		System.out.println("From TestPerson");
		Person person = new Person("chandni", "nair");
		assertEquals("chandni nair", person.getFullName());
	}
	@Test(expected= IllegalArgumentException.class)
	public void testNullsinName(){
		System.out.println("From TestPerson testing Exception");
		Person person = new Person(null, null);
	}
	

}
