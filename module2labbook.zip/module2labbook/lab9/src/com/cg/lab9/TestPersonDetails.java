package com.cg.lab9;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.Test;

public class TestPersonDetails {

	@Test
	public void testGetFirstName(){
		System.out.println("From TestPersonDetails getF_name");
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		assertEquals("Anirudh", person.getF_name());
	}
	
	@Test
	public void testGetLastName(){
		System.out.println("From TestPersonDetails getL_name");
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		assertEquals("Lokapur", person.getL_name());
	}
	
	@Test
	public void testGetGender(){
		System.out.println("From TestPersonDetails getGen");
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		assertEquals('M', person.getGen());
	}
	
	@Test
	public void testGetAge(){
		System.out.println("From TestPersonDetails getAge");
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		assertEquals(22, person.getAge());
	}
	
	@Test
	public void testGetWeight(){
		System.out.println("From TestPersonDetails getWeight");
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		assertEquals(63.5, person.getWht(),0.001);
		
	}

	@Test
	public void testGetPhoneNo(){
		System.out.println("From TestPersonDetails getPhoneNo");
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		assertEquals("8722429900", person.getPhno());
		
	}
	@Test 
	public void testSetFirstName(){
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		person.setF_name("chandni");
		assertTrue(person.getF_name() == "chandni");
	}
	
	@Test 
	public void testSetLastName(){
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		person.setL_name("nair");
		assertTrue(person.getL_name() == "nair");
	}
	
	@Test 
	public void testSetAge(){
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		person.setAge(22);
		assertTrue(person.getAge() == 22);
	}
	
	@Test 
	public void testSetWeight(){
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
		person.setWht(22);
		assertTrue(person.getWht() == 22);
	}
	
	@Test 
	public void testSetPhno(){
		PersonDetails person = new PersonDetails("chandni", "nair", 'F', 22,55.5, "8056342399");
	String phno ="8056342399"; 
	InputStream in = new ByteArrayInputStream(phno.getBytes());
	 System.setIn(in);
		assertEquals("8056342399", person.setPhno());
		
	}
}
