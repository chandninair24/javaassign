package com.capgemini.eis.pl;

import java.util.Scanner;

import com.capgemini.eis.bean.EmployeeBean;
import com.capgemini.eis.service.IEmployeeServiceEIS;
import com.capgemini.eis.service.InsuranceServiceEIS;

public class UserInterfacePl {
public static void main(String[] args) {
	EmployeeBean emp= new EmployeeBean();
	IEmployeeServiceEIS service = new InsuranceServiceEIS();
	Scanner sc = new Scanner (System.in);
	
	System.out.println("Enter the employee ID: ");
	int ID = sc.nextInt();
	
	System.out.println("Enter the employee name:");
	String name = sc.next();
	
	 System.out.println("Enter the salary:");
	 long salary= sc.nextLong();
			 
	 System.out.println("Enter the designation ");
	 String designation = sc.next();
	 
	 emp.setId(ID);
	 emp.setName(name);
	 emp.setSalary(salary);
	 emp.setDesignation(designation);
	
	System.out.println(service.getInsuranceScheme(emp)); 
}
}
