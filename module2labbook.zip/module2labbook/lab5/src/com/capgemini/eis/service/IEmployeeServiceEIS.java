package com.capgemini.eis.service;

import com.capgemini.eis.bean.EmployeeBean;


	public interface IEmployeeServiceEIS{
		

	 public	String getInsuranceScheme(EmployeeBean emp);
	

}
